---
layout: resume
---
# Jayden's Resume.
![avatar](image.jpeg)

<hr>

# Experience
- I have worked at multiple grocery stores and know how to deal with people.

<hr>

# Degree
- degree: High School Diploma
  uni: Paramus Catholic High School
  year: 2023
  award: Just to be successful

<hr>

# Skills
# Drawing and Coloring digitally 
- skill: Drawing/coloring 
  description: Beginner at graphic design, good at drawing.

  <hr>